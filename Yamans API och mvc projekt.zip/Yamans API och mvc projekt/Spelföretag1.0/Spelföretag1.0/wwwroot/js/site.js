﻿document.addEventListener('DOMContentLoaded', () => {
    const select = document.getElementById('category-select');
    const modal = document.getElementById('gameModal');
    const closeBtn = document.querySelector('.close-btn');
    const modalTitle = document.getElementById('modal-title');
    const modalVideo = document.getElementById('modal-video');
    const modalDesc = document.getElementById('modal-desc');
    const apiContainer = document.querySelector('.games-grid');

    //manual cards
    const allCards = document.querySelectorAll('.games-grid .game-card');
    

    // API card
    fetch('http://localhost:5240/api/games')
        .then(res => res.json())
        .then(data => {
            data.forEach(game => {
                console.log('adding game:', game.name); 
                const card = document.createElement('div');
                card.classList.add('game-card');
                card.innerHTML = `
                    <img src="/image/${game.imageUrl}" alt="${game.name}">
                    <p>${game.name} <br><span>${game.category}</span></p>
                `;
                apiContainer.appendChild(card);

                // modal API
                card.addEventListener('click', () => {
                    openModal(game.name, game.videoUrl, game.desc, game.rating);
                });

                allCardsSet.push(card);
            });
        });

    // 3-  API
    let allCardsSet = Array.from(allCards);

    //  Filter by category
    select.addEventListener('change', () => {
        const value = select.value;
        allCardsSet.forEach(card => {
            if (value === 'Alla' || card.innerHTML.includes(value)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });

    // 5- Modal manual card
    allCards.forEach(card => {
        card.addEventListener('click', () => {
            const gameName = card.querySelector('p').innerText.trim().split('\n')[0];
            openModalManual(gameName);
        });
    });

    // 6- Modal function manual card
    const manualGames = {
        "Street Fighter VI": {
            video: "https://www.youtube.com/embed/1INU3FOJsTw",
            desc: "Street Fighter VI är ett klassiskt fighting-spel med nya funktioner och grafik.",
            rating: 5
        },
        "Mario Kart": {
            video: "https://www.youtube.com/embed/NA6CAgv6p6g",
            desc: "Mario Kart är ett racing-spel med färgglada banor och ikoniska karaktärer.",
            rating: 4
        },
        "Pac-Man": {
            video: "https://www.youtube.com/embed/eIkmtqvE2XE",
            desc: "Pac-Man är ett retrospel där du jagar prickar och undviker spöken.",
            rating: 4
        }
    };

    function openModalManual(name) {
        const data = manualGames[name];
        openModal(name, data.video, data.desc, data.rating);
    }

    // 7- Modal open function 
    function openModal(title, video, desc, rating) {
        modalTitle.innerText = title;
        modalVideo.src = video;
        modalDesc.innerHTML = `
            <strong>Rating:</strong> ${'⭐'.repeat(rating)}<br>${desc}
        `;
        modal.style.display = 'flex';
    }

    // 8- close modal
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
        modalVideo.src = "";
    });

    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
            modalVideo.src = "";
        }
    });
});


