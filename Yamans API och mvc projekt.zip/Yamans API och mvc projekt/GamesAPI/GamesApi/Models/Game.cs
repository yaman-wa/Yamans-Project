namespace GamesApi.Models
{
    public class Game
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; } 
        public string VideoUrl { get; set; }
        public string Desc { get; set; }
        public int Rating { get; set; }
        public string ImageUrl { get; set; } 
    }
}