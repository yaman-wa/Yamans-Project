using GamesApi.Data;
using Microsoft.AspNetCore.Mvc;
using GamesApi.Models;

namespace GamesApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GamesController : ControllerBase
    {
        // Injecting DbContext 
        private readonly GameDbContext _context;

        public GamesController(GameDbContext context)
        {
            _context = context;
        }

        // (GET)
        [HttpGet]
        public IActionResult GetAll()
        {
            var games = _context.Games.ToList();
            return Ok(games);
        }

        // ID (GET BY ID)
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var game = _context.Games.FirstOrDefault(g => g.Id == id);
            if (game == null) return NotFound();
            return Ok(game);
        }

        // (POST)
        [HttpPost]
        public IActionResult Create([FromBody] Game newGame)
        {
            _context.Games.Add(newGame);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetById), new { id = newGame.Id }, newGame);
        }

        //(PUT) Edit
        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Game updatedGame)
        {
            var game = _context.Games.FirstOrDefault(g => g.Id == id);
            if (game == null) return NotFound();

            game.Name = updatedGame.Name;
            game.Desc = updatedGame.Desc;
            game.Rating = updatedGame.Rating;
            game.VideoUrl = updatedGame.VideoUrl;
            game.ImageUrl = updatedGame.ImageUrl;

            _context.SaveChanges();
            return NoContent();
        }

        //  (DELETE)
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var game = _context.Games.FirstOrDefault(g => g.Id == id);
            if (game == null) return NotFound();

            _context.Games.Remove(game);
            _context.SaveChanges();
            return NoContent();
        }
    }
}
