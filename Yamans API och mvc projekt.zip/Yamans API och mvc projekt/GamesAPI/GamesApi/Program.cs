using GamesApi.Data;
using GamesApi.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer(); // Swagger
builder.Services.AddSwaggerGen();           // Swagger
builder.Services.AddDbContext<GameDbContext>(options =>
    options.UseSqlite("Data Source=games.db")); // SQLite DB
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowMVC", policy =>
    {
        
        policy.WithOrigins(
                "http://localhost:5192", // MVC
                "http://localhost:5173" // React (Vite)
        )
            
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

var app = builder.Build();



// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();    // <-- Swagger JSON
    app.UseSwaggerUI();  // <-- Swagger UI
}
app.UseCors("AllowMVC");
app.UseStaticFiles(); //load images
app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();


app.Run();
